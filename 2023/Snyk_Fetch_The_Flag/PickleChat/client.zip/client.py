import requests
import base64
import pickle
import time
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import hashes
import argparse


def register_user(username, public_key_pem):
    data = {"username": username, "public_key_pem": public_key_pem}
    response = requests.post(f"{BASE_URL}/register", json=data)
    return response.json()


def send_message(sender, recipient, plain_message):
    # Fetch the recipient's public key
    public_key_pem = get_public_key(recipient)
    public_key = serialization.load_pem_public_key(
        public_key_pem.encode(), backend=default_backend()
    )

    # Encrypt the message with the recipient's public key
    encrypted_message = public_key.encrypt(
        plain_message,
        padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=None,
        ),
    )

    # Prepare data as a dictionary
    data_dict = {
        "sender_id": sender,
        "recipient_id": recipient,
        "encryptedMessage": encrypted_message,
    }

    # Serialize the data for sending
    serialized_data = pickle.dumps(data_dict)
    encoded_message = base64.urlsafe_b64encode(serialized_data).decode()
    response = requests.post(f"{BASE_URL}/send-message", data=encoded_message)

    return response.json()


def get_messages(username):
    response = requests.get(f"{BASE_URL}/get-messages/{username}")
    return response.json()


def get_public_key(username):
    response = requests.get(f"{BASE_URL}/get-public-key/{username}")
    return response.text


def decrypt_message(private_key_filename, username):
    # Read the private key from the file
    with open(private_key_filename, "rb") as key_file:
        private_key_pem = key_file.read()

    private_key = serialization.load_pem_private_key(
        private_key_pem, password=None, backend=default_backend()
    )

    # Fetch messages from the server
    response = get_messages(username)
    if "error" in response:
        if response.get("error") == "No messages found for the user!":
            return f"No messages in queue for {username}"
        return f"Error: {response['error']}"

    # Deserialize and decode the data
    serialized_data = base64.urlsafe_b64decode(response["data"])
    packaged_messages = pickle.loads(serialized_data)

    decrypted_messages = []

    for msg in packaged_messages:
        encrypted_message = msg["content"]
        decrypted_message = private_key.decrypt(
            encrypted_message,
            padding.OAEP(
                mgf=padding.MGF1(algorithm=hashes.SHA256()),
                algorithm=hashes.SHA256(),
                label=None,
            ),
        )
        decrypted_messages.append(
            {"sender": msg["sender"], "content": decrypted_message.decode()}
        )

    return decrypted_messages


def generate_keys():
    private_key = rsa.generate_private_key(
        public_exponent=65537, key_size=2048, backend=default_backend()
    )

    private_key_pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )

    public_key = private_key.public_key()

    public_key_pem = public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    )

    return private_key_pem, public_key_pem


def test():
    try:
        print("[*] Testing public key retrieval for Hammond...")
        hammond_public_key = get_public_key("hammond")
        assert hammond_public_key.startswith(
            "-----BEGIN PUBLIC KEY-----"
        ), "Hammond's public key retrieval failed."
        time.sleep(1)

        # Sending message
        print("[*] Testing send from Husky to Hammond...")
        encrypted_message = b"Hi John!"
        response_send_message = send_message("husky", "hammond", encrypted_message)
        assert (
            response_send_message["message"] == "Message sent successfully!"
        ), "Message sending failed."
        time.sleep(1)

        # Testing decryption on Hammond client side
        print("[*] Testing decryption on Hammond client side...")

        original_message = "Hi John!"

        # Retrieve messages for Hammond
        messages = decrypt_message("hammond_private_key.pem", "hammond")
        message = messages[0]["content"]
        assert (
            message == original_message
        ), "The decrypted message content does not match the original message!"

        print(
            f"[*] Message matches!\n\t-> Original Message: {original_message}\n\t-> Decrypted Message: {message}"
        )

        # Generate new keys for testing
        wrong_private_key_pem, _ = generate_keys()

        # Write wrong private key to a file for testing
        with open("wrong_private_key.pem", "wb") as f:
            f.write(wrong_private_key_pem)

        # Trying decryption with the wrong private key
        print("[*] Testing decryption with wrong private key...")
        response_send_message = send_message("husky", "hammond", encrypted_message)
        time.sleep(1)

        try:
            decrypted_messages_wrong_key = decrypt_message(
                "wrong_private_key.pem", "hammond"
            )

            # If the message is successfully decrypted, then assert that it's not the same as the original message
            assert (
                decrypted_messages_wrong_key[0]["content"] != original_message
            ), "Decryption with wrong key shouldn't produce the original message!"
        except Exception as e:
            print(f"[*] Expected error when decrypting with wrong key: {e}")

        print("[*] Decryption with wrong key test completed!")
        time.sleep(1)
        print("[*] All tests passed")
    except Exception as e:
        print(f"[-] Test error: {e}")


def main():
    parser = argparse.ArgumentParser(
        description="""Client script for sending, receiving, and decrypting messages."""
    )

    parser.add_argument(
        "--url",
        default="http://localhost:5000",
        help="Base URL of the messaging service (default: http://localhost:5000)",
    )

    parser.add_argument("--test", action="store_true", help="Run all tests.")
    parser.add_argument(
        "--register",
        metavar="USERNAME,PUBLIC_KEY_FILE",
        help='Register a user. Provide the username and path to the public key file. E.g., "username,public_key.pem"',
    )
    parser.add_argument(
        "--send",
        metavar="SENDER,RECIPIENT,MESSAGE",
        help='Send a message. Provide the sender username, recipient username, and the message. E.g., "sender,recipient,Hello!"',
    )
    parser.add_argument(
        "--get-messages",
        metavar="USERNAME",
        help='Get messages for a user. Provide the username. E.g., "username"',
    )
    parser.add_argument(
        "--get-public-key",
        metavar="USERNAME",
        help='Get public key for a user. Provide the username. E.g., "username"',
    )

    parser.add_argument(
        "--decrypt",
        metavar="PRIVATE_KEY_FILE,USERNAME",
        help='Decrypt messages. Provide the path to the private key file and username. E.g., "private_key.pem,username"',
    )

    args = parser.parse_args()

    global BASE_URL
    BASE_URL = args.url

    if args.test:
        test()

    elif args.register:
        username, key_file = args.register.split(",")
        with open(key_file, "r") as f:
            public_key_pem = f.read()
        response = register_user(username, public_key_pem)
        print(response)

    elif args.send:
        sender, recipient, message = args.send.split(",")
        response = send_message(sender, recipient, message.encode())
        print(response)

    elif args.get_messages:
        response = get_messages(args.get_messages)
        print(response)

    elif args.get_public_key:
        response = get_public_key(args.get_public_key)
        print(response)

    elif args.decrypt:
        key_file, username = args.decrypt.split(",")
        messages = decrypt_message(key_file, username)
        if isinstance(messages, str) and messages.startswith("No messages"):
            print(f"[*] {messages}")
        else:
            for message in messages:
                print(f"From {message['sender']}: {message['content']}")


if __name__ == "__main__":
    main()
